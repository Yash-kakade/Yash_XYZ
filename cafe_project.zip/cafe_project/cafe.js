const express =require('express');
const app = express();
const port = 3000;

app.listen(port,console.log(`http://localhost:${port}`));

 app.get("/",(req,res)=>res.sendFile(__dirname + "/cafe.html"));
 app.get("/cafe.css",(req,res)=>res.sendFile(__dirname + "/cafe.css"));
 app.get("/food.html",(req,res)=>res.sendFile(__dirname + "/food.html"));
 app.get("/food.css",(req,res)=>res.sendFile(__dirname + "/food.css"));
 app.get("/breverges.html",(req,res)=>res.sendFile(__dirname + "/breverges.html"));
 app.get("/breverges.css",(req,res)=>res.sendFile(__dirname + "/breverges.css"));

// app.use(express.static('public'));